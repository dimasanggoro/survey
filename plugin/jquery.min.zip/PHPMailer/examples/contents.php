<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
  <title>PHPMailer Test</title>
</head>
<body>
<div style="width: 640px; font-family: Arial, Helvetica, sans-serif; font-size: 11px;">
  <h1>This is a test of PHPMailer.</h1>
  <div align="center">
    <a href="https://github.com/PHPMailer/PHPMailer/"><img src="images/phpmailer.png" height="90" width="340" alt="PHPMailer rocks"></a>
  </div>
  <p>This example uses <strong>HTML</strong>.</p>
  <p>ISO-8859-1 text: ���������</p>
</div>


<table id="datanotifstnkkeur" class="table table-hover dataTable">
										<thead>
											
											<tr>
												<td>No.</td>
												<td width="100">No. Polisi</td>
												<td>Jenis</td>
												<td>Merk</td>
												<td width="180">Berakhir STNK</td>

											</tr>
										</thead>
										<tbody>
											<?php
												include ("../../config/koneksi.php");

												//$query = mysqli_query($conn, "SELECT * FROM (SELECT *, TIMESTAMPDIFF(DAY, CURRENT_DATE, ms_ber_stnk) AS stnk, TIMESTAMPDIFF(DAY, CURRENT_DATE, ms_ber_keur) AS keur FROM mobil) as ini WHERE stnk < 10 OR keur < 10 AND jual =1");
												$query = mysqli_query($conn, "SELECT * FROM (SELECT *, TIMESTAMPDIFF(DAY, CURRENT_DATE, ms_ber_stnk) AS stnk FROM mobil) as ini WHERE stnk < 10 AND jual =1");
												$no = 1;
												while ($r = mysqli_fetch_array($query)) {

											?>

										
											<tr>
												<td><?php echo $no; ?></td>
												<td><?php echo $r['plat_no']; ?></td>
												<td><?php echo $r['jenis_kendaraan']; ?></td>
												<td><?php echo $r['merk_kendaraan']; ?></td>
												<td id="<?php echo $r['no_mesin']; ?>"></td>


												
											</tr>
											<?php
												$no++;
												}
												?>
										</tbody>
										
									</table>
</body>
</html>
