<?php

include ("../../config/koneksi.php");


$query = mysqli_query($conn, "SELECT * FROM (SELECT *, TIMESTAMPDIFF(DAY, CURRENT_DATE, ms_ber_stnk) AS stnk FROM mobil u JOIN cabang uc ON u.asalcabang_kendaraan=uc.id) as ini WHERE stnk < 30 AND jual =1 AND asalcabang_kendaraan=25");

$data = mysqli_fetch_array($query);
$num = mysqli_num_rows($query);

if ($num >= 1) {
	# code...
	//echo $data['plat_no'];

	$query1 = mysqli_query($conn, "SELECT * FROM email_notification WHERE id_cabang=25");
	$data1 = mysqli_fetch_array($query1);

	require_once '../PHPMailerAutoload.php';

			$kumailes = $data1['email_penerima']; //masukan email yang akan di set menerima email setiap hari
			 
			$results_messages = array();
			 
			$mail = new PHPMailer(true);
			$mail->CharSet = 'utf-8';
			ini_set('default_charset', 'UTF-8');
			 
			class phpmailerAppException extends phpmailerException {}
			 
			$to = 'dimas.anggoro@enseval.com';
			if(!PHPMailer::validateAddress($to)) {
			  throw new phpmailerAppException("Email address " . $to . " is invalid -- aborting!");
			}
			$mail->isSMTP();
			$mail->SMTPDebug  = 0;
			$mail->Host       = "mail.enseval.com";
			$mail->Port       = "25";
			$mail->SMTPSecure = "none";
			$mail->SMTPAuth   = false;
			$mail->setFrom("admin.fleet@enseval.com", "admin.fleet -- no reply");
			$mail->addAddress('dimas.anggoro@enseval.com', 'dimas');
				 
			
			$mail->isHTML(true);
			$mail->Subject = 'STNK EXPIRE';

			//Read an HTML message body from an external file, convert referenced images to embedded,
			//convert HTML into a basic plain-text alternative body
			include ("../../config/koneksi.php");
			//$query = mysqli_query($conn, "SELECT * FROM (SELECT *, TIMESTAMPDIFF(DAY, CURRENT_DATE, ms_ber_stnk) AS stnk, TIMESTAMPDIFF(DAY, CURRENT_DATE, ms_ber_keur) AS keur FROM mobil) as ini WHERE stnk < 10 OR keur < 10 AND jual =1");
			$query = mysqli_query($conn, "SELECT * FROM (SELECT *, TIMESTAMPDIFF(DAY, CURRENT_DATE, ms_ber_stnk) AS stnk FROM mobil) as ini WHERE stnk < 30 AND jual =1 AND asalcabang_kendaraan=25");
			//Replace the plain text body with one created manually
			$body = '<table style:"border: 1px solid black;"><tr style:"border: 1px solid black;"><th style:"border: 1px solid black;">Nomor Polisi</th><th>Jenis Kendaraan</th></th><th>Pemakai</th><th>Hari</th></tr>';
			while($row = mysqli_fetch_assoc($query)) {
			    $body .= '<tr style:"border: 1px solid black;"><td style:"border: 1px solid black;">'.$row['plat_no'].'</td><td style:"border: 1px solid black;">'.$row['jenis_kendaraan'].'</td><td style:"border: 1px solid black;">'.$row['nama_peg_def'].'</td><td>'.$row['stnk'].'</td></tr>';
			}
			$body .= '</table>';
			$mail->Body    = $body;
			 
			$mail->send();


}

else echo "no data!"

 ?>



